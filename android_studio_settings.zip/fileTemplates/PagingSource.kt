#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import androidx.paging.PagingSource
import androidx.paging.PagingState
import retrofit2.HttpException
import java.io.IOException
import javax.net.ssl.HttpsURLConnection

private const val STARTING_PAGE_INDEX = ${STARTING_PAGE_INDEX}

#parse("File Header.java")
class ${NAME}(
    private val ${API_NAME}: ${API_CLASS}
) : PagingSource<${PAGE_INDICATOR_TYPE}, ${SOURCE_TYPE}>() {

    override suspend fun load(params: LoadParams<${PAGE_INDICATOR_TYPE}>): LoadResult<${PAGE_INDICATOR_TYPE}, ${SOURCE_TYPE}> {
        val position = params.key ?: STARTING_PAGE_INDEX

        return try {
            /**
            ** Make API call here before proceeding
            ** response = *something*
            */

            LoadResult.Page(
                data = response,
                prevKey = if (position == STARTING_PAGE_INDEX) null else position - 1,
                nextKey = if (response.isEmpty()) null else position + 1
            )
        } catch (e: IOException) {
            LoadResult.Error(e)
        } catch (e: HttpException) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<${PAGE_INDICATOR_TYPE}, ${SOURCE_TYPE}>): ${PAGE_INDICATOR_TYPE}? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }
    }
}
