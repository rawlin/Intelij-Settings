#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.LoadState
import androidx.paging.LoadStateAdapter
import androidx.recyclerview.widget.RecyclerView

#parse("File Header.java")
class ${NAME}(private val retry: () -> Unit) : LoadStateAdapter<${NAME}.LoadStateViewHolder>() {

    inner class LoadStateViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        init {
            TODO("Call `retry.invoke()` on OnClick of a retry button")
        }

        fun bind(loadState: LoadState) {
            with(loadState is LoadState.Loading) {
                TODO("Not implemented")
            }
        }

    }

    override fun onBindViewHolder(holder: LoadStateViewHolder, loadState: LoadState) {
        holder.bind(loadState)
    }

    override fun onCreateViewHolder(parent: ViewGroup, loadState: LoadState): LoadStateViewHolder {
        return LoadStateViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.${FooterHeader_Layout_ID}, parent, false)
        )
    }
        
}