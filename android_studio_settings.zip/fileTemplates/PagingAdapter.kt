#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

const val TAG = "${NAME}"

#parse("File Header.java")
class ${NAME}
    : PagingDataAdapter<${ITEM_TYPE}, ${NAME}.${ITEM_VIEW_HOLDER_NAME}>(COMPARATOR) {

    inner class ${ITEM_VIEW_HOLDER_NAME}(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(${ITEM_NAME}: ${ITEM_TYPE}) {
            TODO("not implemented")
        }
    }

    override fun onBindViewHolder(holder: ${ITEM_VIEW_HOLDER_NAME}, position: Int) {
        val currentItem = getItem(position)

        if (currentItem != null) {
            holder.bind(currentItem)
            holder.itemView.setOnClickListener {
                onItemClickListener?.let { it(currentItem) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ${ITEM_VIEW_HOLDER_NAME} {
        return ${ITEM_VIEW_HOLDER_NAME}(
            LayoutInflater.from(parent.context).inflate(R.layout.${Item_Layout_ID}, parent, false)
        )
    }

    private var onItemClickListener: ((${ITEM_TYPE}) -> Unit)? = null

    fun setOnItemClickListener(listener: (${ITEM_TYPE}) -> Unit) {
        onItemClickListener = listener
    }

    companion object {
        private val COMPARATOR = object : DiffUtil.ItemCallback<${ITEM_TYPE}>() {
            override fun areItemsTheSame(oldItem: ${ITEM_TYPE}, newItem: ${ITEM_TYPE}): Boolean {
                TODO("not implemented")
            }
            override fun areContentsTheSame(oldItem: ${ITEM_TYPE}, newItem: ${ITEM_TYPE}): Boolean {
                TODO("not implemented")
            }
        }
    }   
}